#!/usr/bin/env bash
# Packages a release build: packaging/package.sh <linux-x86_64|windows-x86_64|macos-universal|macos> [version]
set -euo pipefail
name="$1"
version="${2:-dev}"
app="Floppy-Copy"
root="$(cd "$(dirname "$0")/.." && pwd)"
cd "$root"
mkdir -p dist
dir="$app-$version-$name"
rm -rf "$dir"

# The embedded fonts (JetBrains Mono, Silkscreen) are under the SIL OFL, whose text must ship with them.
add_licences() {
  cp crates/hgf-gui/assets/fonts/JetBrainsMono-OFL.txt crates/hgf-gui/assets/fonts/Silkscreen-OFL.txt THIRD-PARTY-LICENSES.txt "$1/"
}

# BUNDLE_GW=1: ship the Greaseweazle host tools (Python + gw, see bundle-gw.sh).
bundle_gw() {
  if [ "${BUNDLE_GW:-0}" = 1 ]; then
    bash packaging/bundle-gw.sh "$@"
  fi
}

case "$name" in
  linux-*)
    mkdir -p "$dir"
    cp target/release/floppy-copy "$dir/floppy-copy"
    cp -r packaging/icons "$dir/icons"
    cp packaging/icon.svg "$dir/icons/floppy-copy.svg"
    cp packaging/linux/floppy-copy.desktop packaging/linux/install.sh README.md README.fr.md "$dir/"
    chmod +x "$dir/floppy-copy" "$dir/install.sh"
    add_licences "$dir"
    bundle_gw "$dir/greaseweazle"
    tar czf "dist/$dir.tar.gz" "$dir"
    ;;
  windows-*)
    mkdir -p "$dir"
    cp target/release/floppy-copy.exe "$dir/$app.exe"
    cp README.md README.fr.md "$dir/"
    add_licences "$dir"
    bundle_gw "$dir/greaseweazle"
    [ "${BUNDLE_GW:-0}" = 1 ] || cat > "$dir/GREASEWEAZLE.txt" <<'TXT'
Floppy-Copy needs the Greaseweazle host tools (gw.exe).

Easiest: unzip the official Windows release of the Greaseweazle tools
(https://github.com/keirf/greaseweazle/releases) into this folder, so that you get
    Floppy-Copy.exe
    greaseweazle-x.y\gw.exe
Floppy-Copy finds it automatically. It also finds gw.exe on the PATH,
in Python "Scripts" folders, and in greaseweazle-* folders in Downloads,
Desktop or Documents. Otherwise set its location in Settings.
TXT
    7z a -tzip "dist/$dir.zip" "$dir" > /dev/null
    ;;
  macos-*)
    bundle="$dir/$app.app"
    mkdir -p "$bundle/Contents/MacOS" "$bundle/Contents/Resources"
    # Universal binary from the release workflow, or a plain `cargo build --release` on a Mac.
    bin=target/universal/floppy-copy
    [ -x "$bin" ] || bin=target/release/floppy-copy
    cp "$bin" "$bundle/Contents/MacOS/$app"
    sed "s/@VERSION@/${version#v}/g" packaging/macos/Info.plist > "$bundle/Contents/Info.plist"
    cp packaging/icon.icns "$bundle/Contents/Resources/AppIcon.icns"
    # One Python per processor: the launcher picks the one of the Mac it runs on.
    bundle_gw "$bundle/Contents/Resources/greaseweazle" cpython-3.12-macos-aarch64-none python-arm64
    bundle_gw "$bundle/Contents/Resources/greaseweazle" cpython-3.12-macos-x86_64-none python-x86_64
    cp README.md README.fr.md "$dir/"
    add_licences "$dir"
    ditto -c -k --keepParent "$dir" "dist/$dir.zip"
    ;;
  *)
    echo "unknown target: $name" >&2
    exit 1
    ;;
esac
rm -rf "$dir"
ls -l dist
